<?php

declare(strict_types=1);

namespace App\Http\Controllers\Organisation\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Organisation\Auth\LoginRequest;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

/**
 * ==========================================================================
 * AuthenticatedSessionController
 * ==========================================================================
 *
 * Jalon J1 (auth minimale) - login / logout.
 * ==========================================================================
 */
class AuthenticatedSessionController extends Controller
{
    public function create(): View
    {
        return view('auth.login');
    }
    public function store(LoginRequest $request): RedirectResponse
    {
        $request->authenticate();

        $request->session()->regenerate();

        $user = Auth::user();
        $user->update(['last_login_at' => now()]);

        app(\App\Services\AuditLogger::class)->log($user->id, 'user_logged_in', 'User', $user->id);

        return redirect()->intended(route('dashboard'));
    }

    public function destroy(Request $request): RedirectResponse
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login');
    }
}
